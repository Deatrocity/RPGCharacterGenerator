"""
Author: Ethan Deatrick
Last modified: 12/15/2022
RPG Character Generator
V1.0

This program will let you generate a simplified character sheet to be used in tabletop RPGs. It does this by letting
a user choose their name, race, class, and various stats. The stats selected apply various bonuses, such as +1 damage
for every +1 strength. After all the decisions have been made, a character sheet with the various information will
display. There is a help button to open a window with a brief explanation of the application.
Character information stored in two dictionaries.
    charStats
    keys: "Hit Points", "Mana Points", "damage", "critical strike", "Strength", "Agility", "Endurance", "Intelligence"

    Dictionary to hold Other character info:
    charInfo
    keys: "Name", "Race", "Class"
"""
# Import tkinter
from tkinter import *
from tkinter import messagebox
import tkinter as tk

root = tk.Tk()  # Create the root window
root.title("RPG Character Generator")  # add title to application window
root.resizable(False, False)  # makes the main window not resizable

class CharacterGenerator:
    """Main menu with a couple logos and three buttons to navigate the app. The start button will open a new window
    to begin character creation. The help button will open a new window with a brief explanation of the app. The
    exit button will close the application."""
    def __init__(self, master):
        # Parent class creates main menu window for app
        self.master = master
        # set frame size and background color
        self.frame = tk.Frame(self.master, width=300, height=400, bg="light blue")
        # Create the main menu frame
        self.frame.pack()

        # create widgets for main menu window.
        # Two photos, one as a logo and the other as a space filler to fill out the screen.
        self.logo = tk.PhotoImage(file="logo.png")
        self.logoLabel = tk.Label(image=self.logo)
        self.logo2 = tk.PhotoImage(file="fighter.png")
        self.logo2Label = tk.Label(image=self.logo2)
        # create labels to place next to start and help button
        self.startLabel = tk.Label(self.frame, text="Create new character", bg="light blue", font=14)
        self.helpLabel = tk.Label(self.frame, text="How it works", bg="light blue", font=14)
        # create a start button to begin app, a help button to bring up a new help screen, and exit button to close app.
        self.startButton = tk.Button(self.frame, text="Start", height=1, width=10, font=12, bg="white",
                                     command=self.startnew)
        self.helpButton = tk.Button(self.frame, text="Help", height=1, width=10, font=12, bg="white",
                                    command=self.helpbutton)
        self.exitButton = tk.Button(self.frame, text="Exit", height=1, width=10, font=12, bg="white",
                                    command=self.exit)

        # Place widgets on main window according to x, y values
        # photos
        self.logoLabel.place(x=20, y=20)
        self.logo2Label.place(x=105, y=65)
        # labels
        self.startLabel.place(x=70, y=168)
        self.helpLabel.place(x=97, y=228)
        # buttons
        self.startButton.place(x=95, y=190)
        self.helpButton.place(x=95, y=250)
        self.exitButton.place(x=95, y=310)

    def startnew(self):
        """Opens the character creation window when start button is clicked. Will contain an exit to main menu button
        to close window"""
        # Opens a new screen that begins character creation process. Main menu window is left open.
        self.start = CreateCharacterWindow()
        self.start.window.mainloop()

    def helpbutton(self):
        """Opens a new window when clicked. New window is the 'Help' screen and will show a brief explanation
        of how the application works. Will have an exit to main menu button"""
        # Opens the help window, main menu will remain open.
        self.help = helpScreen()
        self.help.helpWindow.mainloop()

    def exit(self):
        """Closes the program if you click exit button on main menu."""
        exit()


#  Create subclass that will open a new window that begins character creation
class CreateCharacterWindow:
    """Opens the create new character window to begin character creation. A user will be prompted to enter a name, pick
    a class, race, and spend 10 points on their character stats. After, the screen will display a character sheet
    containing information about the character created based on user choices. The main menu will remain open, and the
     new window will contain a button to exit to main menu. Creates two dictionaries to hold stats of character.

    dictionaries created to hold character information:
    charStats
    keys: "Hit Points", "Mana Points", "damage", "critical strike", "Strength", "Agility", "Endurance", "Intelligence"

    Dictionary to hold Other character info:
    charInfo
    keys: "Name", "Race", "Class"

    """
    def __init__(self):  # instantiate child class to create second window.
        #  Create new window that lets user enter their name. Doesn't close main menu. Contains an exit button.
        self.window = tk.Toplevel()  # Use top level widget to show new window on top
        self.window.resizable = (False, False)  # Sets x and y resizable to false
        self.frame = tk.Frame(self.window, width=300, height=400)  # set window size
        self.frame.pack()

        # create widgets for start new character window
        self.charNameEntry = tk.Entry(self.window, width=15)  # entry box to accept character name entry
        # next button will move on to next part of character creation process
        self.nameNext = tk.Button(self.window, text="Confirm", command=self.choosename)
        self.mainLabel = tk.Label(self.window, text="Enter a name for your character", font=("bold", 12))
        # Exit button to close the new window.
        self.exitCreate = tk.Button(self.window, text="Exit to Main Menu", command=self.exitCreateMenu)

        # place widgets on window based on their x and y coordinates
        self.charNameEntry.place(x=95, y=140)
        self.nameNext.place(x=115, y=170)
        self.mainLabel.place(x=38, y=100)
        self.exitCreate.place(x=90, y=360)

        # create dictionaries to hold character stats and information. Set starting values.
        self.charStats = {"Hit Points": 10, "Mana Points": 10, "Damage": 1, "Critical Chance": 5, "Strength": 1,
                          "Agility": 1, "Endurance": 1, "Intelligence": 1}
        self.charInfo = {"Name": "", "Race": "", "Class": ""}

    def choosename(self):
        """Adjusts dictionary value for character name by using .get() on the text in the text entry box. Will make
        sure a name is typed before moving on by checking for an empty string. Will display error message if empty
        string is returned.
        stored in dictionary:
        self.charInfo["Name"]
        """
        if self.charNameEntry.get() == "":  # input validation with error message if empty string is returned
            messagebox.showwarning("Warning!", "Hold up! Please enter a character name to continue")
        else:  # If character name field isn't empty, store the name in charInfo dictionary
            self.charInfo["Name"] = str(self.charNameEntry.get())  # adjust dictionary with input name
            # call method to clear widgets and start next part of creation process
            self.raceSelectionMenu()

    def raceSelectionMenu(self):
        """Closes name window widgets and creates new widgets including radio buttons for a user to select
        a race for their character. There are four different choices, and one must be selected before moving
        on to the next screen, or they will get an error message."""
        # Clear widgets
        self.clearNameMenu()

        # Main label describing purpose of window
        self.mainLabel = tk.Label(self.window, text="Choose a Race", font=("bold", 14))

        # race int variable determines what race is picked when a radio button is picked from below
        self.race = IntVar()

        #  radio buttons for race selection. 4 buttons for human, orc, elf, and dwarf. Values act as keys for reference
        self.humanButton = Radiobutton(self.window, text="Human", variable=self.race, value=1)
        self.orcButton = Radiobutton(self.window, text="Orc", variable=self.race, value=2)
        self.elfButton = Radiobutton(self.window, text="Elf", variable=self.race, value=3)
        self.dwarfButton = Radiobutton(self.window, text="Dwarf", variable=self.race, value=4)
        # Next button that will only work after a race is selected. If pressed before, opens error message
        self.raceNext = tk.Button(self.window, text="Next", command=self.chooseRace)

        # place widgets
        self.mainLabel.place(x=70, y=60)
        self.humanButton.place(x=100, y=100)
        self.orcButton.place(x=100, y=140)
        self.elfButton.place(x=100, y=180)
        self.dwarfButton.place(x=100, y=220)
        self.raceNext.place(x=120, y=290)

    def chooseRace(self):
        """Adjusts dictionary with race picked by checking values of radio buttons in raceSelectionMenu
        with if else statements. Makes sure a race was picked by showing an error message if next button
        is clicked before a choice is made.
        classSelectionMenu() replaces current widgets to move on to class selection window.
        Dictionary value affected:
        charInfo["Race"]
        """
        # if else statements use radio button values made in raceSelectionMenu to determine race selection
        if self.race.get() == 1:  # check race button value to determine race pick
            self.charInfo["Race"] = "Human"  # adjust charInfo dictionary race value based on user selection.
            self.classSelectionMenu()  # move on to class selection
        elif self.race.get() == 2:  # check race button value to determine race pick
            self.charInfo["Race"] = "Orc"  # adjust charInfo dictionary race value based on user selection.
            self.classSelectionMenu()   # move on to class selection
        elif self.race.get() == 3:  # check race button value to determine race pick
            self.charInfo["Race"] = "Elf"  # adjust charInfo dictionary race value based on user selection.
            self.classSelectionMenu()   # move on to class selection
        elif self.race.get() == 4:  # check race button value to determine race pick
            self.charInfo["Race"] = "Dwarf"  # adjust charInfo dictionary race value based on user selection.
            self.classSelectionMenu()   # move on to class selection
        else:  # input validation to make sure a radio button was selected. Shows error message if not.
            messagebox.showwarning("Warning!", "Woah there! Please pick a race to continue.")

    def classSelectionMenu(self):
        """Clears the race selection menu widgets and opens new widgets to show the class selection screen.
        Similar to previous screen. Has three radio buttons, a next button, and an exit button. User must select one of
        the three buttons before they can move on to the next screen by returning an error message if no button
        is selected.
        """
        self.clearRaceMenu()

        # Create main label to explain purpose of screen
        self.mainLabel = tk.Label(self.window, text="Choose a Class", font=("bold", 14))

        # charclass variable made to store value of radio button clicked. Value acts as key for class selection.
        self.charclass = IntVar()

        # Create 3 radio buttons to represent class selection.
        self.fighterButton = Radiobutton(self.window, text="Fighter", variable=self.charclass, value=1)
        self.wizardButton = Radiobutton(self.window, text="Wizard", variable=self.charclass, value=2)
        self.rogueButton = Radiobutton(self.window, text="Rogue", variable=self.charclass, value=3)
        # Create the next button that will return error message if no radio button clicked. Opens next screen if not.
        self.classNext = tk.Button(self.window, text="Next", command=self.chooseClass)

        # Place the widgets on screen
        self.mainLabel.place(x=70, y=60)
        self.fighterButton.place(x=100, y=100)
        self.wizardButton.place(x=100, y=140)
        self.rogueButton.place(x=100, y=180)
        self.classNext.place(x=120, y=290)

    def chooseClass(self):
        """If else statements to determine character class by checking radio button values in classSelectionMenu
        creates the charClass variable
        Dictionary value affected:
        charInfo["Class"]
        """
        # If else statements use charclass variable created in last window. charclass is storing class selection
        if self.charclass.get() == 1:  # .get() returns the variable, checks integer stored to decide what class it is.
            self.charInfo["Class"] = "Fighter"  # Uses charInfo dictionary to store class choice
            self.statSelectionMenu()  # This method clears current window widgets to move on to next window.
        elif self.charclass.get() == 2:
            self.charInfo["Class"] = "Wizard"
            self.statSelectionMenu()
        elif self.charclass.get() == 3:
            self.charInfo["Class"] = "Rogue"
            self.statSelectionMenu()
        else:  # Error message box will open if no radio button is selected when pressing next.
            messagebox.showwarning("Warning!", "Woah, Nelly! Please pick a class to continue.")

    def statSelectionMenu(self):
        """Lets user spend 10 points on their 4 primary attributes to complete character creation. Uses + and - buttons
        to let users decide which stats to adjust. Finalize button will only become available when
        all points are spent."""
        # Clear last menu widgets
        self.clearClassMenu()

        # remaining points to spend on attributes, will control when finalize button becomes available
        self.remainingPoints = 10

        # Creates 2 labels for each stat to show attribute name as well as a number to show what current value is
        self.mainLabel = tk.Label(self.window, text="Disperse your stat points", font=("bold", 14))
        self.strLabel = tk.Label(self.window, text="Strength", font=12)
        self.strNum = tk.Label(self.window, text=str(self.charStats["Strength"]), font=("bold", 15))
        self.agiLabel = tk.Label(self.window, text="Agility", font=12)
        self.agiNum = tk.Label(self.window, text=str(self.charStats["Agility"]), font=("bold", 15))
        self.endLabel = tk.Label(self.window, text="Endurance", font=12)
        self.endNum = tk.Label(self.window, text=str(self.charStats["Endurance"]), font=("bold", 15))
        self.intLabel = tk.Label(self.window, text="Intelligence", font=12)
        self.intNum = tk.Label(self.window, text=str(self.charStats["Intelligence"]), font=("bold", 15))
        # label to show how many points remaining to spend on stats
        self.remainingLabel = tk.Label(self.window, text="Remaining points:", font=15)
        self.remainingNumber = tk.Label(self.window, text=self.remainingPoints, font=("bold", 15))

        # Create a + and a - button for each stat to increase and decrease stat. Will adjust remaining points to spend.
        self.strUp = tk.Button(self.window, text="+", command=self.strUp)
        self.strDown = tk.Button(self.window, text="-", command=self.strDown)
        self.strDown["state"] = DISABLED  # disable '-' button so value cant go below 1
        self.agiUp = tk.Button(self.window, text="+", command=self.agiUp)
        self.agiDown = tk.Button(self.window, text="-", command=self.agiDown)
        self.agiDown["state"] = DISABLED  # disable '-' button so value cant go below 1
        self.endUp = tk.Button(self.window, text="+", command=self.endUp)
        self.endDown = tk.Button(self.window, text="-", command=self.endDown)
        self.endDown["state"] = DISABLED  # disable '-' button so value cant go below 1
        self.intUp = tk.Button(self.window, text="+", command=self.intUp)
        self.intDown = tk.Button(self.window, text="-", command=self.intDown)
        self.intDown["state"] = DISABLED  # disable '-' button so value cant go below 1

        # finalize button to complete character creation. Only becomes enabled after remainingPoints reach 0
        self.finalizeButton = tk.Button(self.window, text="Finalize", command=self.charSheet)
        # Disable button until remaining points = 0.
        self.finalizeButton["state"] = DISABLED

        # Place the widgets
        # place Strength labels and buttons
        self.strLabel.place(x=30, y=55)
        self.strNum.place(x=150, y=55)
        self.strUp.place(x=175, y=55)
        self.strDown.place(x=125, y=55)
        # place Agility labels and buttons
        self.agiLabel.place(x=30, y=105)
        self.agiNum.place(x=150, y=100)
        self.agiUp.place(x=175, y=100)
        self.agiDown.place(x=125, y=100)
        # place Endurance labels and buttons
        self.endLabel.place(x=30, y=155)
        self.endNum.place(x=150, y=150)
        self.endUp.place(x=175, y=150)
        self.endDown.place(x=125, y=150)
        # place Intelligence
        self.intLabel.place(x=30, y=205)
        self.intNum.place(x=150, y=200)
        self.intUp.place(x=175, y=200)
        self.intDown.place(x=125, y=200)
        # place main label
        self.mainLabel.place(x=40, y=10)
        # place finalize button
        self.finalizeButton.place(x=118, y=300)
        # place remaining points label
        self.remainingLabel.place(x=20, y=260)
        self.remainingNumber.place(x=155, y=256)


    def strUp(self):
        """Increases strength by 1 and reduces available points by 1 on button click."""
        # adjust remaining points and attribute selected
        self.remainingPoints -= 1
        self.charStats["Strength"] += 1
        # change the number widgets on screen representing the attribute selected and remaining points
        self.strNum.destroy()  # destroy the strength label
        self.strNum = tk.Label(self.window, text=str(self.charStats["Strength"]), font=("bold", 15))  # create new label
        self.strNum.place(x=150, y=55)  # place the new strength label
        self.remainingNumber.destroy()  # destroy remaining points label
        self.remainingNumber = tk.Label(self.window, text=self.remainingPoints, font=("bold", 15))  # recreate label
        self.remainingNumber.place(x=155, y=256)  # place new reaming points label.
        # make sure stat can't go below 1 by disabling '-' button functionality if it reaches 1.
        self.strDown["state"] = NORMAL
        if self.charStats["Strength"] == 1:
            self.strDown["state"] = DISABLED
        # if remaining points run out after button press, disables all "+" buttons. Finalize button becomes enabled.
        if self.remainingPoints == 0:
            self.finalizeButton["state"] = NORMAL
            self.strUp["state"] = DISABLED
            self.agiUp["state"] = DISABLED
            self.endUp["state"] = DISABLED
            self.intUp["state"] = DISABLED

    def strDown(self):
        """Reduces strength by 1 and increases available points by 1 on button click."""
        # adjust remaining points and attribute selected
        self.remainingPoints += 1
        self.charStats["Strength"] -= 1
        # change the number widgets on screen representing the attribute selected and remaining points
        self.strNum.destroy()  # destroy the strength label
        self.strNum = tk.Label(self.window, text=str(self.charStats["Strength"]), font=("bold", 15))  # create new label
        self.strNum.place(x=150, y=55)
        self.remainingNumber.destroy()
        self.remainingNumber = tk.Label(self.window, text=self.remainingPoints, font=("bold", 15))  # create new label
        self.remainingNumber.place(x=155, y=256)
        # Makes sure stat selected can't go below 0 by disabling button when stat = 1
        if self.charStats["Strength"] == 1:
            self.strDown["state"] = DISABLED
        elif self.charStats["Strength"] > 1:
            self.strDown["state"] = NORMAL
        # ensures the "+" buttons are enabled and finalize button disabled if remaining points are above 0.
        if self.remainingPoints != 0:
            self.finalizeButton["state"] = DISABLED
            self.strUp["state"] = NORMAL
            self.agiUp["state"] = NORMAL
            self.endUp["state"] = NORMAL
            self.intUp["state"] = NORMAL

    def agiUp(self):
        """Increases agility by 1 and reduces available points by 1 on button click."""
        # adjust remaining points and attribute selected
        self.remainingPoints -= 1
        self.charStats["Agility"] += 1
        # change the number widgets on screen representing the attribute selected and remaining points
        self.agiNum.destroy()  # destroy number label
        self.agiNum = tk.Label(self.window, text=str(self.charStats["Agility"]), font=("bold", 15))  # recreate label
        self.agiNum.place(x=150, y=100)  # place label widget
        self.remainingNumber.destroy()  # destroy remaining number label
        self.remainingNumber = tk.Label(self.window, text=self.remainingPoints, font=("bold", 15))  # recreate label
        self.remainingNumber.place(x=155, y=256)  # place new remaining label widget
        # make sure stat can't go below 1 by disabling '-' button functionality if it reaches 1.
        self.agiDown["state"] = NORMAL
        if self.charStats["Agility"] == 1:
            self.agiDown["state"] = DISABLED
        # if remaining points run out after button press, disables all "+" buttons. Enables the finalize button
        if self.remainingPoints == 0:
            self.finalizeButton["state"] = NORMAL
            self.strUp["state"] = DISABLED
            self.agiUp["state"] = DISABLED
            self.endUp["state"] = DISABLED
            self.intUp["state"] = DISABLED

    def agiDown(self):
        """Reduces agility by 1 and increases available points by 1 on button click."""
        # adjust remaining points and attribute selected
        self.remainingPoints += 1
        self.charStats["Agility"] -= 1
        # change the number widgets on screen representing the attribute selected and remaining points
        self.agiNum.destroy()  # destroy number label
        self.agiNum = tk.Label(self.window, text=str(self.charStats["Agility"]), font=("bold", 15))  # recreate label
        self.agiNum.place(x=150, y=100)
        self.remainingNumber.destroy()
        self.remainingNumber = tk.Label(self.window, text=self.remainingPoints, font=("bold", 15))  # recreate label
        self.remainingNumber.place(x=155, y=256)
        # Makes sure stat selected can't go below 0 by disabling button when stat = 1
        if self.charStats["Agility"] == 1:
            self.agiDown["state"] = DISABLED
        elif self.charStats["Agility"] > 1:
            self.agiDown["state"] = NORMAL
        # ensures the "+" buttons are enabled and finalize button disabled if remaining points are above 0.
        if self.remainingPoints != 0:
            self.finalizeButton["state"] = DISABLED
            self.strUp["state"] = NORMAL
            self.agiUp["state"] = NORMAL
            self.endUp["state"] = NORMAL
            self.intUp["state"] = NORMAL

    def endUp(self):
        """Increases endurance by 1 and reduces available points by 1 on button click."""
        # adjust remaining points and attribute selected
        self.remainingPoints -= 1
        self.charStats["Endurance"] += 1
        # change the number widgets on screen representing the attribute selected and remaining points
        self.endNum.destroy()  # destroy number label
        self.endNum = tk.Label(self.window, text=str(self.charStats["Endurance"]), font=("bold", 15))  # create label
        self.endNum.place(x=150, y=150)
        self.remainingNumber.destroy()
        self.remainingNumber = tk.Label(self.window, text=self.remainingPoints, font=("bold", 15))  # create new label
        self.remainingNumber.place(x=155, y=256)
        # make sure stat can't go below 1 by disabling '-' button functionality if it reaches 1.
        self.endDown["state"] = NORMAL
        if self.charStats["Endurance"] == 1:
            self.endDown["state"] = DISABLED
        # if remaining points run out after button press, disables all other "+" buttons.
        if self.remainingPoints == 0:
            self.finalizeButton["state"] = NORMAL
            self.strUp["state"] = DISABLED
            self.agiUp["state"] = DISABLED
            self.endUp["state"] = DISABLED
            self.intUp["state"] = DISABLED

    def endDown(self):
        """reduces endurance by 1 and increases available points by 1 on button click."""
        # adjust remaining points and attribute selected
        self.remainingPoints += 1
        self.charStats["Endurance"] -= 1
        # change the number widgets on screen representing the attribute selected and remaining points
        self.endNum.destroy()  # destroy number label
        self.endNum = tk.Label(self.window, text=str(self.charStats["Endurance"]), font=("bold", 15))  # create new label
        self.endNum.place(x=150, y=150)
        self.remainingNumber.destroy()
        self.remainingNumber = tk.Label(self.window, text=self.remainingPoints, font=("bold", 15))  # create new label
        self.remainingNumber.place(x=155, y=256)
        # Makes sure stat selected can't go below 0 by disabling button when stat = 1
        if self.charStats["Endurance"] == 1:
            self.endDown["state"] = DISABLED
        elif self.charStats["Endurance"] > 1:
            self.endDown["state"] = NORMAL
        # ensures the "+" buttons are enabled and finalize button disabled if remaining points are above 0.
        if self.remainingPoints != 0:
            self.finalizeButton["state"] = DISABLED
            self.strUp["state"] = NORMAL
            self.agiUp["state"] = NORMAL
            self.endUp["state"] = NORMAL
            self.intUp["state"] = NORMAL

    def intUp(self):
        """Increases intelligence by 1 and reduces available points by 1 on button click."""
        # adjust remaining points and attribute selected
        self.remainingPoints -= 1
        self.charStats["Intelligence"] += 1
        # change the number widgets on screen representing the attribute selected and remaining points
        self.intNum.destroy()  # destroy number label
        self.intNum = tk.Label(self.window, text=str(self.charStats["Intelligence"]), font=("bold", 15))  # create new label
        self.intNum.place(x=150, y=200)
        self.remainingNumber.destroy()
        self.remainingNumber = tk.Label(self.window, text=self.remainingPoints, font=("bold", 15))  # create new label
        self.remainingNumber.place(x=155, y=256)
        # make sure stat can't go below 1 by disabling '-' button functionality if it reaches 1.
        self.intDown["state"] = NORMAL
        if self.charStats["Intelligence"] == 1:
            self.intDown["state"] = DISABLED
        # if remaining points run out after button press, disables all other "+" buttons.
        if self.remainingPoints == 0:
            self.finalizeButton["state"] = NORMAL
            self.strUp["state"] = DISABLED
            self.agiUp["state"] = DISABLED
            self.endUp["state"] = DISABLED
            self.intUp["state"] = DISABLED


    def intDown(self):
        """Reduces intelligence by 1 and increases available points by 1 on button click."""
        # adjust remaining points and attribute selected
        self.remainingPoints += 1
        self.charStats["Intelligence"] -= 1
        # Update stat selected and remaining points widgets
        self.intNum.destroy()  # destroy int label
        self.intNum = tk.Label(self.window, text=str(self.charStats["Intelligence"]), font=("bold", 15))  # create new label
        self.intNum.place(x=150, y=200)  # place new int label
        self.remainingNumber.destroy()
        self.remainingNumber = tk.Label(self.window, text=self.remainingPoints, font=("bold", 15))  # create new label
        self.remainingNumber.place(x=155, y=256)
        # Makes sure stat selected can't go below 0 by disabling button when stat = 1
        if self.charStats["Intelligence"] == 1:
            self.intDown["state"] = DISABLED
        elif self.charStats["Intelligence"] > 1:
            self.intDown["state"] = NORMAL
        # ensures the "+" buttons are enabled and finalize button disabled if remaining points are above 0.
        if self.remainingPoints != 0:
            self.finalizeButton["state"] = DISABLED
            self.strUp["state"] = NORMAL
            self.agiUp["state"] = NORMAL
            self.endUp["state"] = NORMAL
            self.intUp["state"] = NORMAL

    def charSheet(self):
        # Clear last menu
        self.clearStatMenu()
        # apply stat bonuses to stats. such as 1 strength resulting in +1 damage
        self.addStatBonus()

        # create label widgets to show all the user selected character info
        self.nameLabel = tk.Label(self.window, text="Name: "+self.charInfo["Name"], font=("bold", 14))
        self.classLabel = tk.Label(self.window, text="Level 1 " + self.charInfo["Race"] + " " + self.charInfo["Class"],
                                   font=("bold", 14))
        self.hitPointLabel = tk.Label(self.window, text="Health:    " + str(self.charStats["Hit Points"]), font=13)
        self.manaPointLabel = tk.Label(self.window, text="Mana:     " + str(self.charStats["Mana Points"]), font=13)
        self.damageLabel = tk.Label(self.window, text="Damage:     " + str(self.charStats["Damage"]), font=13)
        self.criticalLabel = tk.Label(self.window, text="Critical:     " + (str(self.charStats["Critical Chance"]) +
                                                                               "%"), font=13)
        self.strengthLabel = tk.Label(self.window, text="Strength:         " + str(self.charStats["Strength"]), font=13)
        self.agilityLabel = tk.Label(self.window, text="Agility:             " + str(self.charStats["Agility"]), font=13)
        self.enduranceLabel = tk.Label(self.window, text="Endurance:     " + str(self.charStats["Endurance"]), font=13)
        self.intelligenceLabel = tk.Label(self.window, text="Intelligence:     " + str(self.charStats["Intelligence"]),
                                          font=13)
        # Place label widgets on screen to represent character sheet
        self.nameLabel.place(x=25, y=20)
        self.classLabel.place(x=25, y=45)
        self.hitPointLabel.place(x=25, y=85)
        self.manaPointLabel.place(x=25, y=103)
        self.damageLabel.place(x=160, y=155)
        self.criticalLabel.place(x=160, y=180)
        self.strengthLabel.place(x=25, y=155)
        self.agilityLabel.place(x=25, y=180)
        self.enduranceLabel.place(x=25, y=205)
        self.intelligenceLabel.place(x=25, y=230)

    def addStatBonus(self):
        """Applies the stat bonuses. Every attribute will be adjusted as follows: These will be added to the
        starting values of each attribute.
        Every 1 Endurance = +5 hp
        Every 1 Intelligence = +5 mp
        Every 1 Strength = +1 damage
        Every 1 Agility = +1 crit chance"""
        self.charStats["Hit Points"] += (self.charStats["Endurance"] * 5)
        self.charStats["Mana Points"] += (self.charStats["Intelligence"] * 5)
        self.charStats["Damage"] += self.charStats["Strength"]
        self.charStats["Critical Chance"] += self.charStats["Agility"]

    # The rest of the methods are to clear the various menus of their widgets
    def clearNameMenu(self):
        """clears widgets on the name selection menu"""
        # Destroy all current widgets except exit button.
        self.mainLabel.destroy()
        self.nameNext.destroy()
        self.charNameEntry.destroy()

    def clearRaceMenu(self):
        """Clears widgets on race selection window"""
        # Destroy all current widgets except exit button.
        self.mainLabel.destroy()
        self.humanButton.destroy()
        self.orcButton.destroy()
        self.elfButton.destroy()
        self.dwarfButton.destroy()
        self.raceNext.destroy()

    def clearClassMenu(self):
        """Clears widgets on class selection window"""
        # Destroy all current widgets except exit button.
        self.mainLabel.destroy()
        self.fighterButton.destroy()
        self.wizardButton.destroy()
        self.rogueButton.destroy()
        self.classNext.destroy()

    def clearStatMenu(self):
        """Clears widgets on the stat selection window"""
        #  destroy all widgets on stat selection window
        self.strLabel.destroy()
        self.strNum.destroy()
        self.strUp.destroy()
        self.strDown.destroy()
        self.endLabel.destroy()
        self.endNum.destroy()
        self.endUp.destroy()
        self.endDown.destroy()
        self.agiLabel.destroy()
        self.agiNum.destroy()
        self.agiUp.destroy()
        self.agiDown.destroy()
        self.intLabel.destroy()
        self.intNum.destroy()
        self.intUp.destroy()
        self.intDown.destroy()
        self.finalizeButton.destroy()
        self.remainingLabel.destroy()
        self.remainingNumber.destroy()
        self.mainLabel.destroy()


    def exitCreateMenu(self):
        """Exits to main menu from create window. Will close current window, but main menu will remain open"""
        self.window.destroy()


class helpScreen:
    """The help screen will be displayed after a user clicks the "help" button on the main screen.
    It will display a brief discription of the application, and will have a button to exit to the
    main menu."""
    def __init__(self):
        # This is the message that will be displayed on the help screen.
        self.helpText = """
This program will allow you to create a 
character to be used in a tabletop RPG. 
First you will be asked to choose a name, 
then a race, and finally a class. After 
that, you will have 10 stat points to 
spend on your four main attributes. After 
you click finalize, a character sheet will 
be generated with various information.
                
The stats you choose will have an effect 
on the final character sheet. You start
with 10 health, 10 mana, 1 damage, and 
5% critical strike chance.
+1 Strength = +1 damage
+1 Agility = +1% crit chance
+1 Endurance = +5 health
+1 Intelligence = +5 mana
                """
        #  Create new window
        self.helpWindow = tk.Toplevel()
        self.helpWindow.resizable = (False, False)  # Sets x and y resizable to false
        self.frame = tk.Frame(self.helpWindow, width=300, height=400)  # set window size
        self.frame.pack()
        # create exit button and help message
        self.exitHelp = tk.Button(self.helpWindow, text="Exit to Main Menu", command=self.exitHelpMenu)
        self.helpLabel = tk.Label(self.helpWindow, text=self.helpText, font=("bold", 12))
        # place widgets
        self.exitHelp.place(x=90, y=360)
        self.helpLabel.place(x=2, y=10)


    def exitHelpMenu(self):
        """Exits to main menu from help window"""
        self.helpWindow.destroy()


if __name__ == "__main__":  # Will execute code if file is ran directly
    window = CharacterGenerator(root)
    root.mainloop()
